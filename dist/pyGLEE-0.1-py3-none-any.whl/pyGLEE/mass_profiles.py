class NoMass():
    pass